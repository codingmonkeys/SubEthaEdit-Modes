Include is a template to generate symbol popup images.
For best results save your final image as an 12x12 png image.