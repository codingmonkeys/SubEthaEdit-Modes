## Mode for SQL.

Ported Version of the formerly built-in SubEthaEdit Mode, July 2014.
