## Mode for Apache thrift.

Initial Version by Thomas Bartelmess - [https://github.com/tbartelmess](https://github.com/tbartelmess), June 2014.

See [http://thrift.apache.org/docs/idl](http://thrift.apache.org/docs/idl) for the language definition.

Examples: 

* [https://github.com/apache/thrift/blob/master/test/StressTest.thrift](https://github.com/apache/thrift/blob/master/test/StressTest.thrift)
* [https://github.com/apache/thrift/blob/master/test/Include.thrift](https://github.com/apache/thrift/blob/master/test/Include.thrift)
