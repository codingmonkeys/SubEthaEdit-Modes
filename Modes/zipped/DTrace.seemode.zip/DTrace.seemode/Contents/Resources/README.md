## Mode for dtrace.

Initial Version by Thomas Bartelmess - [https://github.com/tbartelmess](https://github.com/tbartelmess), June 2014.
